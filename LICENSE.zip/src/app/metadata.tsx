import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Kişisel Blog',
  description: 'Kişisel blog sitesi',
}; 